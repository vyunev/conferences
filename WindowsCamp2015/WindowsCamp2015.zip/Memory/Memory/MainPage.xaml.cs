﻿using System;
using System.Collections.Generic;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace Memory
{
    public sealed partial class MainPage : Page
    {
        static List<string> array = new List<string>();
        public MainPage()
        {
            this.InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < 10; i++)
            {
                array.Add(DateTime.UtcNow.ToString());
            }
        }
    }
}