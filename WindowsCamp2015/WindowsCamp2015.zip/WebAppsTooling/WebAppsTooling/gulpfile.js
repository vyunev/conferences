﻿var gulp = require("gulp");

gulp.task("copy", function () {
    gulp.src("./bower_components/jquery/dist/*.min.{js}").pipe(gulp.dest("./js"));
    gulp.src("./bower_components/bootstrap/dist/fonts/**").pipe(gulp.dest("./fonts"));
    gulp.src("./bower_components/bootstrap/dist/css/*.min*").pipe(gulp.dest("./css"));
    gulp.src("./bower_components/bootstrap/dist/js/*.min*").pipe(gulp.dest("./js"));
});