﻿using System;

namespace Sychev.Dotnext
{
    public class Program
    {
        public void Main(string[] args)
        {
			Console.WriteLine("Start working with Redis");
			Examples.WriteValuesInRedis();
			Console.WriteLine("End work with Redis");
			Console.ReadLine();
		}
	}
}
