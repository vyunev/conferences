﻿using System;
using Dotnext.Datastore;

namespace Sychev.Dotnext.Redis.Host
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Start working with Redis");
            //SharedExamples.WriteValues(MyContextStore.CreateContext(Ext.AddRedisFunc, Ext.AddRedisFunc));
             Examples.Read();
            //Examples.Read();
            Console.WriteLine("End work with Redis");
            Console.ReadLine();
        }
    }
}
