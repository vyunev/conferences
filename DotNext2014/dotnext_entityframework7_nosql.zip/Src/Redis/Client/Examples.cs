﻿using System;
using System.Diagnostics;
using System.Linq;
using Dotnext.Datastore;
using Microsoft.Data.Entity;
using Sychev.Dotnext.DataModels;

namespace Sychev.Dotnext.Redis.Client
{
    public class Examples
    {
        public static void ReadInclude()
        {
            using (var context = MyContextStore.CreateContext(Ext.AddRedisFunc, Ext.AddRedisFunc))
            {
                var readedUserWithSession = context.Set<UserWithSession>().First();
                if (readedUserWithSession.User == null || (readedUserWithSession.UserSession == null))
                {
                    Debugger.Break();
                }
                var readedUserWithSessionInclude = context.Set<UserWithSession>().Include(i => i.User).First();
            }
        }

        public static void Read()
        {
            //InsertMillion();

            var searchConst = new Random(DateTime.UtcNow.Millisecond).Next(1, 100000);

            //heating
            Heating(searchConst);


            WhereNoIndex(searchConst);
            FirstNoIndex(searchConst);

            WhereIndex(searchConst);
            FirstIndex(searchConst);
        }

        private static void Heating(int searchConst)
        {
            var stopWatch = new Stopwatch();

            using (DbContext context = MyContextStore.CreateContext(Ext.AddRedisFunc, Ext.AddRedisFunc))
            {
                stopWatch.Start();
                var context1 = context.Set<UserForSearch>();
                var search = context1.FirstOrDefault(cur => cur.Id == searchConst);
                stopWatch.Stop();
            }

            Console.WriteLine("Heating: ellased {0}", stopWatch.ElapsedMilliseconds);
        }

        private const int iteration = 1;

        private static void WhereNoIndex(int searchConst)
        {
            var stopWatch = new Stopwatch();
            for (int i = 0; i < iteration; i++)
            {
                using (DbContext context = MyContextStore.CreateContext(Ext.AddRedisFunc, Ext.AddRedisFunc))
                {
                    stopWatch.Start();
                    //var search = context.Set<UserForSearch>().Where(cur => cur.Something == searchConst).ToList();
                    //Console.WriteLine("{0}",search.Count);
                    searchConst = new Random().Next(1, 170000);
                    var search = context.Set<UserForSearch>().Where(cur => cur.Something == searchConst).ToList().Count();
                    //Console.WriteLine("{0}", search);
                    stopWatch.Stop();
                }
            }
            Console.WriteLine("SearchWhere No Index: ellased {0}", stopWatch.ElapsedMilliseconds);
        }
      
        private static void FirstNoIndex(int searchConst)
        {
            var stopWatch = new Stopwatch();
            for (int i = 0; i < iteration; i++)
            {
                using (DbContext context = MyContextStore.CreateContext(Ext.AddRedisFunc, Ext.AddRedisFunc))
                {
                    stopWatch.Start();
                    searchConst = new Random().Next(1, 170000);
                    var search = context.Set<UserForSearch>().FirstOrDefault(cur => cur.Something == searchConst);
                    //Console.WriteLine("{0}", search.Id);
                    stopWatch.Stop();
                }
            }
            Console.WriteLine("SearchFirst No Index: ellased {0}", stopWatch.ElapsedMilliseconds);
        }

        private static void FirstIndex(int searchConst)
        {
            var stopWatch = new Stopwatch();
            for (int i = 0; i < iteration; i++)
            {
                using (DbContext context = MyContextStore.CreateContext(Ext.AddRedisFunc, Ext.AddRedisFunc))
                {
                    stopWatch.Start();
                    searchConst = new Random().Next(1, 170000);
                    var search = context.Set<UserForSearch>().FirstOrDefault(cur => cur.Id == searchConst);
                    stopWatch.Stop();
                }
            }
            Console.WriteLine("SearchFirst With Index: ellased {0}", stopWatch.ElapsedMilliseconds);
        }

        private static void WhereIndex(int searchConst)
        {
            var stopWatch = new Stopwatch();
            for (int i = 0; i < iteration; i++)
            {
                using (DbContext context = MyContextStore.CreateContext(Ext.AddRedisFunc, Ext.AddRedisFunc))
                {
                    stopWatch.Start();
                    //var search = context.Set<UserForSearch>().Where(cur => cur.Id == searchConst).ToList();
                    //Console.WriteLine("{0}", search.Count);
                    searchConst = new Random().Next(1, 170000);
                    var search = context.Set<UserForSearch>().Where(cur => cur.Id == searchConst).ToArray().Count();
                    //Console.WriteLine("{0}", search);
                    stopWatch.Stop();
                }
            }
            Console.WriteLine("SearchWhere With Index: ellased {0}", stopWatch.ElapsedMilliseconds);
        }
        private static void InsertMillion()
        {
            var stopWatch = new Stopwatch();
            stopWatch.Start();
            using (DbContext context = MyContextStore.CreateContext(Ext.AddRedisFunc, Ext.AddRedisFunc))
            {
                var set = context.Set<UserForSearch>();
                for (int i = 1; i < 100000; i++)
                {
                    set.Add(new UserForSearch
                    {
                        Id = i,
                        Name = i.ToString(),
                        Something = i
                    });
                    if (i % 1000 == 0)
                    {
                        Console.WriteLine(i);
                        context.SaveChanges();
                    }
                }
            }
            stopWatch.Stop();
            Console.WriteLine(stopWatch.ElapsedMilliseconds);
        }
    }
}