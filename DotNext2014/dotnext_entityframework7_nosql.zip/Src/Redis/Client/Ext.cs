using Microsoft.Data.Entity;
using Microsoft.Data.Entity.Redis.Extensions;
using Microsoft.Framework.DependencyInjection;

namespace Sychev.Dotnext.Redis.Client
{
    public static class Ext
    {
        public static EntityServicesBuilder AddRedisFunc(this EntityServicesBuilder builder)
        {
            return builder.AddRedis();
        }

        public static DbContextOptions AddRedisFunc(this DbContextOptions builder)
        {
            return builder.UseRedis();
        }
    }
}