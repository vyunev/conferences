﻿CREATE TABLE [dbo].[User] (
    [Id]         INT            NOT NULL,
    [FamilyName] NVARCHAR (MAX) NULL,
    [Name]       NVARCHAR (MAX) NULL,
    [Sex]        INT            NOT NULL,
    CONSTRAINT [PK_User] PRIMARY KEY CLUSTERED ([Id] ASC)
);

