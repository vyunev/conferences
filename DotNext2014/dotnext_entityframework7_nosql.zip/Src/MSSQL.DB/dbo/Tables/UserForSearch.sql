﻿CREATE TABLE [dbo].[UserForSearch] (
    [Id]         INT            NOT NULL,
    [FamilyName] NVARCHAR (MAX) NULL,
    [Name]       NVARCHAR (MAX) NULL,
    [Sex]        INT            NOT NULL,
    [Something]  INT            NOT NULL,
    CONSTRAINT [PK_UserForSearch] PRIMARY KEY CLUSTERED ([Id] ASC)
);

