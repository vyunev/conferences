﻿CREATE TABLE [dbo].[UserExtended] (
    [Id]         INT            NOT NULL,
    [FamilyName] NVARCHAR (MAX) NULL,
    [IsAdmin]    BIT            NOT NULL,
    [Name]       NVARCHAR (MAX) NULL,
    [Sex]        INT            NOT NULL,
    CONSTRAINT [PK_UserExtended] PRIMARY KEY CLUSTERED ([Id] ASC)
);

