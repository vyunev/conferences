﻿CREATE TABLE [dbo].[UserSession] (
    [Id]    INT            NOT NULL,
    [Value] NVARCHAR (MAX) NULL,
    CONSTRAINT [PK_UserSession] PRIMARY KEY CLUSTERED ([Id] ASC)
);

