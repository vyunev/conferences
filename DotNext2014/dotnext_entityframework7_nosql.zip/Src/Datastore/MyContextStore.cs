using System;
using Microsoft.Data.Entity;
using Microsoft.Data.Entity.Metadata;
using Microsoft.Framework.DependencyInjection;
using Microsoft.Framework.DependencyInjection.Fallback;
using Sychev.Dotnext.DataModels;

namespace Dotnext.Datastore
{
    public class MyContextStore
    {
        public static DbContext CreateContext(
            Func<EntityServicesBuilder, EntityServicesBuilder> addDbProvider, 
            Func<DbContextOptions, DbContextOptions> addDbProviderOption)
        {
            var options = addDbProviderOption(new DbContextOptions()
                .UseModel(CreateModel()));

            return new DbContext(GetServiceProvider(addDbProvider), options);
        }

        protected static IServiceProvider GetServiceProvider(Func<EntityServicesBuilder, EntityServicesBuilder> addDbProvider)
        {
            var provider = addDbProvider(new ServiceCollection()
                .AddEntityFramework())
                .ServiceCollection
                .BuildServiceProvider();

            return provider;
        }


        private static IModel CreateModel()
        {
            var model = new Model();
            var builder = new ModelBuilder(model);

            builder.Entity<User>(b =>
            {
                b.Key(cust => cust.Id);
            });
            builder.Entity<UserForSearch>(b =>
            {
                b.Key(cust => cust.Id);
            });
            builder.Entity<UserSession>(b =>
            {
                b.Key(cust => cust.Id);
            });
            builder.Entity<UserExtended>(b =>
            {
                b.Key(cust => cust.Id);
            });

            builder.Entity<UserWithSession>(b =>
            {
                b.Key(cust => cust.Id);
                b.OneToOne(curt => curt.User);
            });
            return model;
        }
    }
}