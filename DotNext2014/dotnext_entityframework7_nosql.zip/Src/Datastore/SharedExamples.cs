﻿using System;
using Microsoft.Data.Entity;
using Sychev.Dotnext.DataModels;

namespace Dotnext.Datastore
{
    public class SharedExamples
    {
        public static void WriteValues(DbContext dbContext)
        {
            using (var context = dbContext)
            {
                var ivanIvanovich = context.Set<User>().Add(
                    new User
                    {
                        Id = 100,
                        Name = "Ivan",
                        FamilyName = "Ivanovich",
                        Sex = Sex.M
                    });
                var igorYurivich = context.Set<UserExtended>().Add(
                    new UserExtended
                    {
                        Id = 200,
                        Name = "Igor",
                        IsAdmin = true,
                        Sex = Sex.M,
                        FamilyName = "Sychev"
                    });
                context.SaveChanges();

                var session = context.Set<UserSession>().Add(
                    new UserSession
                    {
                        Id = 150,
                        Value = "hask150",
                    });

                context.SaveChanges();

                //Debugger.Break();
                ivanIvanovich.Name = "Petr Petrovich";
                context.SaveChanges();

                context.Set<User>().Remove(ivanIvanovich);
                context.SaveChanges();

                var validationAbsent = context.Set<UserWithSession>().Add(new UserWithSession
                {
                    Id = 15000,
                    User = ivanIvanovich,
                    UserSession = session
                });
                context.SaveChanges();
            }
        }
    }
}