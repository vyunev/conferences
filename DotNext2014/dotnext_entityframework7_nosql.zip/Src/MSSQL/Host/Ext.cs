using System.Configuration;
using Microsoft.Data.Entity;
using Microsoft.Framework.DependencyInjection;

namespace Sychev.Dotnext.MSSQL.Host
{
    public static class Ext
    {
        public static EntityServicesBuilder AddMSSQLFunc(this EntityServicesBuilder builder)
        {
            return builder.AddSqlServer();
        }

        public static DbContextOptions AddMSSQLFunc(this DbContextOptions builder)
        {
            return builder.UseSqlServer(ConfigurationManager.ConnectionStrings["ef"].ConnectionString);
        }
    }
}