﻿using System;
using Dotnext.Datastore;

namespace Sychev.Dotnext.MSSQL.Host
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Start working with MSSQL");
            SharedExamples.WriteValues(MyContextStore.CreateContext(Ext.AddMSSQLFunc, Ext.AddMSSQLFunc));
            Console.WriteLine("End work with MSSQL");
            Console.ReadLine();
        }
    }
}
