using System;
using Microsoft.Data.Entity;

namespace Sychev.Dotnext.MSSQL.Host
{
    public class MyDbContext : DbContext
    {

        public MyDbContext()
            : base()
        {
        }


        public MyDbContext(IServiceProvider provider, DbContextOptions options)
            : base(provider, options)
        {
            // Database.AsMigrationsEnabled().CreateTables();
        }
    }
}