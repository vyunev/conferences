using System;
using Microsoft.Data.Entity;

namespace Sychev.Dotnext.ATS.Host
{
    public class ATSDbContext : DbContext
    {

        public ATSDbContext()
            : base()
        {
        }


        public ATSDbContext(IServiceProvider provider, DbContextOptions options)
            : base(provider, options)
        {
            //Database.AsAzureTableStorage().EnsureCreated();
        }
    }
}