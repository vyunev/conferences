using System;
using Dotnext.Datastore;
using Microsoft.Data.Entity;
using Microsoft.Data.Entity.Metadata;
using Sychev.Dotnext.DataModels;

namespace Sychev.Dotnext.ATS.Host
{
    public class ATSContextStore : MyContextStore
    {
        public static ATSDbContext CreateContext(
            Func<EntityServicesBuilder, EntityServicesBuilder> addDbProvider,
            Func<DbContextOptions, DbContextOptions> addDbProviderOption)
        {
            var options = addDbProviderOption(new DbContextOptions()
                .UseModel(CreateModel()));

            return new ATSDbContext(GetServiceProvider(addDbProvider), options);
        }

        private static IModel CreateModel()
        {
            var model = new Model();
            var builder = new ModelBuilder(model);

            builder.Entity<User>()
                .ForAzureTableStorage()
                .PartitionAndRowKey(c => c.Id, c => c.FamilyName);

            builder.Entity<UserForSearch>()
                .ForAzureTableStorage()
                .PartitionAndRowKey(c => c.Id, c => c.FamilyName);

            builder.Entity<UserSession>()
                .ForAzureTableStorage()
                .PartitionAndRowKey(c => c.Id, c => c.Value);

            builder.Entity<UserExtended>().ForAzureTableStorage()
                .PartitionAndRowKey(c => c.Id, c => c.FamilyName);

            return model;
        }
    }
}