﻿using System;
using Dotnext.Datastore;

namespace Sychev.Dotnext.ATS.Host
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Start working with AzureTableStorage");
            SharedExamples.WriteValues(ATSContextStore.CreateContext(Ext.AddAzureTableStorageFunc, Ext.AddAzureTableStorageFunc));
            Console.WriteLine("End work with AzureTableStorage");
            Console.ReadLine();
        }
    }
}
