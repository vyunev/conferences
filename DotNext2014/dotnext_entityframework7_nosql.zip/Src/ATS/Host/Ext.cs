using System.Configuration;
using Microsoft.Data.Entity;
using Microsoft.Framework.DependencyInjection;

namespace Sychev.Dotnext.ATS.Host
{
    public static class Ext
    {
        public static EntityServicesBuilder AddAzureTableStorageFunc(this EntityServicesBuilder builder)
        {
            return builder.AddAzureTableStorage();
        }

        public static DbContextOptions AddAzureTableStorageFunc(this DbContextOptions builder)
        {
            return builder.UseAzureTableStorage("dotnext", "9ZAnDVw5ymUxH+grqA6M7zDIG1EoY/rENM71mKQ9Hpf1ikPTM82ajwvXX4mRNxiDuFTJuUAOHBaveMwB5pj+SQ==");
        }
    }
}