namespace Sychev.Dotnext.DataModels
{
    public class UserForSearch : User
    {
        public int Something { get; set; }
    }
}