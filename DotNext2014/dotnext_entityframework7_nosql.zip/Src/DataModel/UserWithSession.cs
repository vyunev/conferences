namespace Sychev.Dotnext.DataModels
{
    public class UserWithSession
    {
        public int Id { get; set; }

        public User User { get; set; }

        public virtual UserSession UserSession { get; set; }
    }
}