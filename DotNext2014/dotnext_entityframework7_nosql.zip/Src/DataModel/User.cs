namespace Sychev.Dotnext.DataModels
{
    public class User
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string FamilyName { get; set; }

        public Sex Sex { get; set; }
    }
}