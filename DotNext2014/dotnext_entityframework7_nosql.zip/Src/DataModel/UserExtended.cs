namespace Sychev.Dotnext.DataModels
{
    public class UserExtended : User
    {
        public bool IsAdmin { get; set; }
    }
}