﻿namespace Sychev.Dotnext.DataModels
{
    public class UserSession
    {
        public int Id { get; set; }
        public string Value { get; set; }
    }
}