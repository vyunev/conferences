namespace Sychev.Dotnext.DataModels
{
    public enum Sex
    {
        M = 1,
        W = 0
    }
}