﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sychev.Dotnext.DataModels;

namespace MemoryConsumption.EF6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("EF6");
            using (var context = new MyDbContext())
            {
                var users = context.Users.Take(10000).ToArray();
                Console.ReadLine();
            }
        }
    }

    public class MyDbContext : DbContext
    {

        public MyDbContext()
            : base("ef")
        {
        }

        public DbSet<User> Users { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
           // modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
        }
    }
}
