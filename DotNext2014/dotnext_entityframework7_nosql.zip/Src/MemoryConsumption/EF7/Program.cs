﻿using System;
using System.Configuration;
using System.Linq;
using Microsoft.Data.Entity;
using Microsoft.Data.Entity.Metadata;
using Microsoft.Framework.DependencyInjection;
using Microsoft.Framework.DependencyInjection.Fallback;
using Sychev.Dotnext.DataModels;

namespace MemoryConsumption.EF7
{
    class Program
    {
        static void Main(string[] args)
        {
            //WriteValues(MyContextStore.CreateContext(Ext.AddMSSQLFunc, Ext.AddMSSQLFunc));
            Console.WriteLine("EF7");
            using (var context = MyContextStore.CreateContext(Ext.AddMSSQLFunc, Ext.AddMSSQLFunc))
            {
                var users = context.Set<User>().Take(10000).ToArray();
                Console.ReadLine();
            }
        }

        public static void WriteValues(DbContext dbContext)
        {
            using (var context = dbContext)
            {
                for (int i = 10000; i < 100000; i++)
                {
                    var ivanIvanovich = context.Set<User>().Add(
                        new User
                        {
                            Name = "Ivan" + i,
                            FamilyName = "Ivanovich",
                            Sex = Sex.M
                        });

                }
                context.SaveChanges();
            }
        }
    }

    public static class Ext
    {
        public static EntityServicesBuilder AddMSSQLFunc(this EntityServicesBuilder builder)
        {
            return builder.AddSqlServer();
        }

        public static DbContextOptions AddMSSQLFunc(this DbContextOptions builder)
        {
            return builder.UseSqlServer(ConfigurationManager.ConnectionStrings["ef"].ConnectionString);
        }
    }

    public class MyDbContext : DbContext
    {

        public MyDbContext()
            : base()
        {
        }


        public MyDbContext(IServiceProvider provider, DbContextOptions options)
            : base(provider, options)
        {
            //Database.AsMigrationsEnabled().CreateTables();
        }
    }

    public class MyContextStore
    {
        public static MyDbContext CreateContext(Func<EntityServicesBuilder, EntityServicesBuilder> addDbProvider, Func<DbContextOptions, DbContextOptions> addDbProviderOption)
        {
            var options = addDbProviderOption(new DbContextOptions()
                .UseModel(CreateModel()));

            return new MyDbContext(GetServiceProvider(addDbProvider), options);
        }

        private static IServiceProvider GetServiceProvider(Func<EntityServicesBuilder, EntityServicesBuilder> addDbProvider)
        {
            var provider = addDbProvider(new ServiceCollection()
                .AddEntityFramework())
                .ServiceCollection
                .BuildServiceProvider();

            return provider;
        }


        private static IModel CreateModel()
        {
            var model = new Model();
            var builder = new ModelBuilder(model);

            builder.Entity<User>(b =>
            {
                b.Key(cust => cust.Id);
            });
            builder.Entity<UserForSearch>(b =>
            {
                b.Key(cust => cust.Id);
            });
            builder.Entity<UserSession>(b =>
            {
                b.Key(cust => cust.Id);
            });
            builder.Entity<UserExtended>(b =>
            {
                b.Key(cust => cust.Id);
            });

            //builder.Entity<UserWithSession>(b =>
            //{
            //    b.Key(cust => cust.Id);
            //    b.OneToOne(curt => curt.User);
            //});
            return model;
        }
    }
}
